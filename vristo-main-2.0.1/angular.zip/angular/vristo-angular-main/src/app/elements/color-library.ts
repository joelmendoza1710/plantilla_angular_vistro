import { Component } from '@angular/core';

@Component({
    templateUrl: './color-library.html',
})
export class ColorLibraryComponent {
    constructor() {}
}
