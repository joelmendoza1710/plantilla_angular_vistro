import { Component } from '@angular/core';
@Component({
    templateUrl: './typography.html',
})
export class TypographyComponent {
    constructor() {}
}
