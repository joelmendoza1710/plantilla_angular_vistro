import { Component } from '@angular/core';

@Component({
    templateUrl: './user-account-settings.html',
})
export class UserAccountSettingsComponent {
    activeTab = 'home';
    constructor() {}
}
