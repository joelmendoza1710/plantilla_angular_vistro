import { Component } from '@angular/core';

@Component({
    templateUrl: './index.html',
})
export class IndexComponent {}
