<template>
    <footer class="border-t border-black-light/20 py-5">
        <div class="container">
            <p class="text-center text-sm">
                Copyright ©{{ new Date().getFullYear() }} All rights reserved by <span class="font-bold text-primary hover:underline">SBThemes</span>.
            </p>
        </div>
    </footer>
</template>
