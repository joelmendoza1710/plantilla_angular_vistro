<template>
    <div
        class="sidebar fixed top-0 -left-[260px] z-[51] w-[260px] flex-none bg-white shadow-[5px_0_25px_0_rgba(94,92,154,0.1)] duration-500 lg:relative lg:left-0"
    >
        <div class="sticky top-0">
            <div class="p-3">
                <NuxtLink :to="`/${route.query.type ? '?type=' + route.query.type : ''}`" class="inline-flex items-center gap-2">
                    <img class="ml-[5px] w-8 flex-none" src="/assets/images/logo.svg" alt="image" />
                    <span class="text-2xl font-semibold">VRISTO</span>
                </NuxtLink>
            </div>
            <div class="h-[calc(100vh_-_60px)] overflow-auto border-t border-dashed border-black-light/30 pb-5">
                <ul class="text-[15px] font-semibold" @click="$emit('closeSidebar')">
                    <li>
                        <NuxtLink
                            :to="`/documentation${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Getting Started
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'html'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            HTML Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'angular'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-angular${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Angular Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'vue', 'nuxt', 'vue-laravel'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-vue${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Vue Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'vue', 'nuxt', 'vue-laravel'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-nuxt${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Nuxt Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'react', 'next', 'react-laravel'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-react${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            React Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'react', 'next', 'react-laravel'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-next-page-directory${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Next Page Router Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'react', 'next', 'react-laravel'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-next-app-directory${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Next App Router Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'laravel', 'php', 'cakephp', 'codeigniter', 'symfony'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-php${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            PHP Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'laravel', 'php', 'cakephp', 'codeigniter', 'symfony'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-laravel${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Laravel Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'react', 'next', 'react-laravel'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-react-laravel${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            React + Laravel Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'vue', 'nuxt', 'vue-laravel'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-vue-laravel${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Vue + Laravel Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'laravel', 'php', 'cakephp', 'codeigniter', 'symfony'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-cakephp${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            CakePHP Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'laravel', 'php', 'cakephp', 'codeigniter', 'symfony'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-codeigniter${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            CodeIgniter Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'laravel', 'php', 'cakephp', 'codeigniter', 'symfony'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-symfony${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Symfony Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'django'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-django${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Django Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'ruby'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-ruby${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Ruby Installation
                        </NuxtLink>
                    </li>
                    <li v-if="['all', 'adonis'].includes(typeData?.type)">
                        <NuxtLink
                            :to="`/documentation/installation-adonis${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Adonis Installation
                        </NuxtLink>
                    </li>
                    <li>
                        <NuxtLink
                            :to="`/documentation/intro-layouts${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Layouts
                        </NuxtLink>
                    </li>
                    <li>
                        <NuxtLink
                            :to="`/documentation/theme-integration${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Theme Integration
                        </NuxtLink>
                    </li>
                    <li>
                        <NuxtLink
                            :to="`/documentation/theme-color-customization${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Theme Color Customization
                        </NuxtLink>
                    </li>
                    <li>
                        <NuxtLink
                            :to="`/documentation/attributions${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Attributions
                        </NuxtLink>
                    </li>

                    <li>
                        <NuxtLink
                            :to="`/documentation/support${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Support
                        </NuxtLink>
                    </li>

                    <li>
                        <NuxtLink
                            :to="`/documentation/changelog${route.query.type ? '?type=' + route.query.type : ''}`"
                            class="block py-2 px-4 duration-500 hover:bg-black-light/10 hover:pl-6 hover:text-primary"
                        >
                            Changelog
                        </NuxtLink>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>
<script setup>
    const typeData = useAttrs().typeData;
    const route = useRoute();
</script>
