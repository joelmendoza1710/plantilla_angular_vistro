export default {
    getTypeData(lang = 'all') {
        const type = lang.toLowerCase();
        let data = {
            type: 'all',
            url: 'https://1.envato.market/Jzb2Vq',
            title: 'HTML 5, Angular Js, ReactJS, VueJS, NextJS, NuxtJs, PHP, Laravel, React + Laravel, Vue + Laravel, CakePHP, CodeIgniter, Symfony, DJango, Ruby On Rails, AdonisJS',
            logos: [
                { image: 'html.svg', name: 'HTML' },
                { image: 'angular.svg', name: 'Angular' },
                { image: 'reactjs.svg', name: 'React' },
                { image: 'nextjs.svg', name: 'Next' },
                { image: 'vuejs.svg', name: 'Vue' },
                { image: 'nuxtjs.svg', name: 'Nuxt' },
                { image: 'php.svg', name: 'PHP' },
                { image: 'laravel.svg', name: 'Laravel' },
                { image: 'cakephp.svg', name: 'CakePHP' },
                { image: 'codeigniter.svg', name: 'CodeIgniter' },
                { image: 'symfony.svg', name: 'Symfony' },
                { image: 'django.svg', name: 'Django' },
                { image: 'ruby.svg', name: 'Ruby' },
                { image: 'adonis.svg', name: 'Adonis' },
                { image: 'reactjs+laravel.svg', name: 'React + Laravel' },
                { image: 'vuejs+laravel.svg', name: 'Vue + Laravel' },
                { image: 'alpine.svg', name: 'Alpine' },
            ],
            demoUrl: 'https://html.vristo.sbthemes.com',
        };
        if (type === 'next' || type === 'react' || type === 'react-laravel') {
            data = {
                type: 'next',
                url: 'https://1.envato.market/75k7a5',
                title: 'NextJS, ReactJS, React + Laravel',
                logos: [
                    { image: 'reactjs.svg', name: 'React' },
                    { image: 'nextjs.svg', name: 'Next' },
                    { image: 'reactjs+laravel.svg', name: 'React + Laravel' },
                ],
                demoUrl: 'https://react.vristo.sbthemes.com',
            };
        } else if (type === 'nuxt' || type === 'vue' || type === 'vue-laravel') {
            data = {
                type: 'nuxt',
                url: 'https://1.envato.market/EKNvrD',
                title: 'VueJS, NuxtJs, Vue + Laravel',
                logos: [
                    { image: 'vuejs.svg', name: 'Vue' },
                    { image: 'nuxtjs.svg', name: 'Nuxt' },
                    { image: 'vuejs+laravel.svg', name: 'Vue + Laravel' },
                ],
                demoUrl: 'https://vue.vristo.sbthemes.com',
            };
        } else if (type === 'php' || type === 'laravel' || type === 'cakephp' || type === 'codeigniter' || type === 'symfony') {
            data = {
                type: 'laravel',
                url: 'https://1.envato.market/Jzb2Vq',
                title: 'Laravel, PHP, CakePHP, CodeIgniter, Symfony',
                logos: [
                    { image: 'laravel.svg', name: 'Laravel' },
                    { image: 'php.svg', name: 'PHP' },
                    { image: 'cakephp.svg', name: 'CakePHP' },
                    { image: 'codeigniter.svg', name: 'CodeIgniter' },
                    { image: 'symfony.svg', name: 'Symfony' },
                    { image: 'alpine.svg', name: 'Alpine' },
                ],
                demoUrl: 'https://html.vristo.sbthemes.com',
            };
        } else if (type === 'django') {
            data = {
                type: 'django',
                url: 'https://1.envato.market/Jzb2Vq',
                title: 'Django',
                logos: [
                    { image: 'django.svg', name: 'Django' },
                    { image: 'alpine.svg', name: 'Alpine' },
                ],
                demoUrl: 'https://html.vristo.sbthemes.com',
            };
        } else if (type === 'ruby') {
            data = {
                type: 'ruby',
                url: 'https://1.envato.market/Jzb2Vq',
                title: 'Ruby',
                logos: [
                    { image: 'ruby.svg', name: 'Ruby' },
                    { image: 'alpine.svg', name: 'Alpine' },
                ],
                demoUrl: 'https://html.vristo.sbthemes.com',
            };
        } else if (type === 'adonis') {
            data = {
                type: 'adonis',
                url: 'https://1.envato.market/Jzb2Vq',
                title: 'Adonis',
                logos: [
                    { image: 'adonis.svg', name: 'Adonis' },
                    { image: 'alpine.svg', name: 'Alpine' },
                ],
                demoUrl: 'https://html.vristo.sbthemes.com',
            };
        } else if (type === 'html') {
            data = {
                type: 'html',
                url: 'https://1.envato.market/Jzb2Vq',
                title: 'HTML 5',
                logos: [
                    { image: 'html.svg', name: 'HTML' },
                    { image: 'alpine.svg', name: 'Alpine' },
                ],
                demoUrl: 'https://html.vristo.sbthemes.com',
            };
        } else if (type === 'angular') {
            data = {
                type: 'angular',
                url: 'https://1.envato.market/Qyg39Y',
                title: 'Angular',
                logos: [{ image: 'angular.svg', name: 'Angular' }],
                demoUrl: 'https://angular.vristo.sbthemes.com',
            };
        }

        return data;
    },
};
