<template>
    <div class="space-y-5">
        <h2 class="text-2xl font-bold text-primary">Attributions</h2>

        <div class="panel">
            <h3 class="mb-5 text-xl font-bold text-success">Images</h3>

            <div class="w-full overflow-x-auto">
                <table class="w-full border border-black-light/10 text-left text-black-light">
                    <thead>
                        <tr>
                            <th class="border border-black-light/10 bg-black-light/5 px-4 py-2 text-black">Source</th>
                            <th class="border border-black-light/10 bg-black-light/5 px-4 py-2 text-black">Url</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Unsplash</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <a href="https://unsplash.com/" class="text-success hover:text-black" target="_blank">https://unsplash.com/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Undraw</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <a href="https://undraw.co/" class="text-success hover:text-black" target="_blank">https://undraw.co/</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="panel">
            <h3 class="mb-5 text-xl font-bold text-success">Special Thanks</h3>

            <div class="w-full overflow-x-auto">
                <table class="w-full border border-black-light/10 text-left text-black-light">
                    <thead>
                        <tr>
                            <th class="border border-black-light/10 bg-black-light/5 px-4 py-2 text-black">Source</th>
                            <th class="border border-black-light/10 bg-black-light/5 px-4 py-2 text-black">Url</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Alpine Js</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Alpine Js 3:</b>
                                <a href="https://alpinejs.dev/" class="text-success hover:text-black" target="_blank">https://alpinejs.dev/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Angular Js</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular 15:</b>
                                <a href="https://angular.io/" class="text-success hover:text-black" target="_blank">https://angular.io/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Vue Js</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue 3:</b>
                                <a href="https://vuejs.org/" class="text-success hover:text-black" target="_blank">https://vuejs.org/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Nuxt Js</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Nuxt 3:</b>
                                <a href="https://nuxt.com/docs/getting-started/introduction" class="text-success hover:text-black" target="_blank"
                                    >https://nuxt.com/docs/getting-started/introduction</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">React Js</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React 18:</b>
                                <a href="https://reactjs.org/docs/getting-started.html" class="text-success hover:text-black" target="_blank"
                                    >https://reactjs.org/docs/getting-started.html</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Next Js</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Next 13:</b>
                                <a href="https://nextjs.org/docs/getting-started" class="text-success hover:text-black" target="_blank"
                                    >https://nextjs.org/docs/getting-started</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Laravel</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Laravel 9:</b>
                                <a href="https://laravel.com/" class="text-success hover:text-black" target="_blank">https://laravel.com/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">CakePHP</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">CakePHP 4:</b>
                                <a href="https://cakephp.org/" class="text-success hover:text-black" target="_blank">https://cakephp.org/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">CodeIgniter</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">CodeIgniter 4:</b>
                                <a href="https://codeigniter.com/" class="text-success hover:text-black" target="_blank">https://codeigniter.com/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Symfony</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Symfony 6:</b>
                                <a href="https://symfony.com/" class="text-success hover:text-black" target="_blank">https://symfony.com/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Django</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Django 4:</b>
                                <a href="https://www.djangoproject.com/" class="text-success hover:text-black" target="_blank"
                                    >https://www.djangoproject.com/</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Ruby</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Ruby 7:</b>
                                <a href="https://www.ruby-lang.org/" class="text-success hover:text-black" target="_blank">https://www.ruby-lang.org/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">Adonis</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Adonis 5:</b>
                                <a href="https://adonisjs.com/" class="text-success hover:text-black" target="_blank">https://adonisjs.com/</a>
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="2">Tailwind CSS</td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Tailwind 3:</b>
                                <a href="https://tailwindcss.com/docs/installation" class="text-success hover:text-black" target="_blank"
                                    >https://tailwindcss.com/docs/installation</a
                                >
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="panel">
            <h3 class="mb-5 text-xl font-bold text-success">Plugins</h3>

            <div class="w-full overflow-x-auto">
                <table class="w-full border border-black-light/10 text-left text-black-light">
                    <thead>
                        <tr>
                            <th class="border border-black-light/10 bg-black-light/5 px-4 py-2 text-black">Source</th>
                            <th class="border border-black-light/10 bg-black-light/5 px-4 py-2 text-black">Url</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2"><b class="text-dark">Animate.css</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <a href="https://www.npmjs.com/package/animate.css" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/animate.css</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="5"><b class="text-dark">i18n</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/@ngx-translate/core" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@ngx-translate/core</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js:</b>
                                <a href="https://www.npmjs.com/package/vue-i18n" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue-i18n</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/@nuxtjs/i18n" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@nuxtjs/i18n</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js:</b>
                                <a href="https://www.npmjs.com/package/react-i18next" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-i18next</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Next Js:</b>
                                <a href="https://www.npmjs.com/package/i18next" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/i18next</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4">
                                <b class="text-dark">Perfect Scrollbar</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/perfect-scrollbar" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/perfect-scrollbar</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ngx-scrollbar" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ngx-scrollbar</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue3-perfect-scrollbar" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue3-perfect-scrollbar</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-perfect-scrollbar" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-perfect-scrollbar</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="2"><b class="text-dark">Highlightjs</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/highlight.js" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/highlight.js</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ngx-highlightjs" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ngx-highlightjs</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="3"><b class="text-dark">Tab</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://alpinejs.dev/component/tabs" class="text-success hover:text-black" target="_blank"
                                    >https://alpinejs.dev/component/tabs</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://headlessui.com/vue/tabs" class="text-success hover:text-black" target="_blank"
                                    >https://headlessui.com/vue/tabs</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://headlessui.com/react/tabs" class="text-success hover:text-black" target="_blank"
                                    >https://headlessui.com/react/tabs</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="3">
                                <b class="text-dark">Accordions</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://alpinejs.dev/component/accordion" class="text-success hover:text-black" target="_blank"
                                    >https://alpinejs.dev/component/accordion</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue-height-collapsible" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue-height-collapsible</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-animate-height" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-animate-height</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Modal</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://alpinejs.dev/component/modal" class="text-success hover:text-black" target="_blank"
                                    >https://alpinejs.dev/component/modal</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/angular-custom-modal" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/angular-custom-modal</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://headlessui.com/vue/dialog" class="text-success hover:text-black" target="_blank"
                                    >https://headlessui.com/vue/dialog</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://headlessui.com/react/dialog" class="text-success hover:text-black" target="_blank"
                                    >https://headlessui.com/react/dialog</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2"><b class="text-dark">Swiper</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <a href="https://www.npmjs.com/package/swiper" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/swiper</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Counter</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/countup.js" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/countup.js</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ngx-countup" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ngx-countup</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue-countup-v3" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue-countup-v3</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-countup" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-countup</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2"><b class="text-dark">Sweet Alert</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <a href="https://www.npmjs.com/package/sweetalert2" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/sweetalert2</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Lightbox</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/@fancyapps/ui" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@fancyapps/ui</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ngx-lightbox" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ngx-lightbox</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue-easy-lightbox" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue-easy-lightbox</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-image-lightbox" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-image-lightbox</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Dropdown</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://alpinejs.dev/component/dropdown" class="text-success hover:text-black" target="_blank"
                                    >https://alpinejs.dev/component/dropdown</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/headlessui-angular" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/headlessui-angular</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue3-popper" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue3-popper</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-popper" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-popper</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Tooltip</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/tippy.js" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/tippy.js</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ngx-tippy-wrapper" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ngx-tippy-wrapper</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/tippy.vue" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/tippy.vue</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/@tippyjs/react" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@tippyjs/react</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Chart</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/apexcharts" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/apexcharts</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ng-apexcharts" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ng-apexcharts</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue3-apexcharts" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue3-apexcharts</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-apexcharts" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-apexcharts</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4">
                                <b class="text-dark">Darg &amp; Drop</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/sortablejs" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/sortablejs</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/@dustfoundation/ngx-sortablejs" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@dustfoundation/ngx-sortablejs</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue-draggable-next" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue-draggable-next</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-sortablejs" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-sortablejs</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4">
                                <b class="text-dark">Full Calendar</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/fullcalendar" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/fullcalendar</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/@fullcalendar/angular" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@fullcalendar/angular</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/@fullcalendar/vue3" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@fullcalendar/vue3</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/@fullcalendar/react" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@fullcalendar/react</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Datatable</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/simple-datatables" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/simple-datatables</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/@bhplugin/ng-datatable" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@bhplugin/ng-datatable</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/@bhplugin/vue3-datatable" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@bhplugin/vue3-datatable</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/mantine-datatable" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/mantine-datatable</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="2">
                                <b class="text-dark">Form Validation</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vuelidate" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vuelidate</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/formik" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/formik</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4">
                                <b class="text-dark">Input Mask</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://alpinejs.dev/plugins/mask" class="text-success hover:text-black" target="_blank"
                                    >https://alpinejs.dev/plugins/mask</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/angular2-text-mask" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/angular2-text-mask</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/maska" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/maska</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-text-mask" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-text-mask</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Select2</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/nice-select2" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/nice-select2</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/@ng-select/ng-select" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@ng-select/ng-select</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/@suadelabs/vue3-multiselect" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/@suadelabs/vue3-multiselect</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-select" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-select</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="2"><b class="text-dark">Touchspin</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/vue3-number-spinner" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue3-number-spinner</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue3-number-spinner" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue3-number-spinner</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2"><b class="text-dark">Form Wizard</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue3-form-wizard" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue3-form-wizard</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="2"><b class="text-dark">File Upload</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js, Vue Js, Nuxt Js &amp; Angular Js:</b>
                                <a href="https://www.npmjs.com/package/file-upload-with-preview" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/file-upload-with-preview</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-images-uploading" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-images-uploading</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4">
                                <b class="text-dark">Quill Editor</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/quilljs" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/quilljs</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ngx-quill" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ngx-quill</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue3-quill" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue3-quill</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-quill" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-quill</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4">
                                <b class="text-dark">Markdown Editor</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/easymde" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/easymde</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ngx-easymde" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ngx-easymde</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue3-easymde" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue3-easymde</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-simplemde-editor" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-simplemde-editor</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Flatpickr</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/flatpickr" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/flatpickr</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ng2-flatpickr" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ng2-flatpickr</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue-flatpickr-component" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue-flatpickr-component</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-flatpickr" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-flatpickr</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4">
                                <b class="text-dark">NoUI Slider</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/nouislider" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/nouislider</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ng2-nouislider" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ng2-nouislider</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue-simple-range-slider" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue-simple-range-slider</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/nouislider-react" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/nouislider-react</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="4"><b class="text-dark">Clipboard</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Js:</b>
                                <a href="https://www.npmjs.com/package/clipboard" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/clipboard</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ngx-clipboard" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ngx-clipboard</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue-clipboard3" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue-clipboard3</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-copy-to-clipboard" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-copy-to-clipboard</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2" rowspan="3">
                                <b class="text-dark">Json Excel</b>
                            </td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Angular Js:</b>
                                <a href="https://www.npmjs.com/package/ang-json2excel-btn" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/ang-json2excel-btn</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">Vue Js &amp; Nuxt Js:</b>
                                <a href="https://www.npmjs.com/package/vue3-json-excel" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/vue3-json-excel</a
                                >
                            </td>
                        </tr>
                        <tr>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-export-table-to-excel" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-export-table-to-excel</a
                                >
                            </td>
                        </tr>

                        <tr>
                            <td class="border border-black-light/10 px-4 py-2"><b class="text-dark">Click Away Listener</b></td>
                            <td class="border border-black-light/10 px-4 py-2">
                                <b class="mr-1 text-primary">React Js &amp; Next Js:</b>
                                <a href="https://www.npmjs.com/package/react-click-away-listener" class="text-success hover:text-black" target="_blank"
                                    >https://www.npmjs.com/package/react-click-away-listener</a
                                >
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
    definePageMeta({
        layout: 'app-layout',
    });
</script>
