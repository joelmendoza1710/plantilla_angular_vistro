<template>
    <div class="space-y-5">
        <h2 class="text-2xl font-bold text-primary">Changelog</h2>

        <div class="panel space-y-5">
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 2.0.0 - 19 October, 2024</p>
                <div class="space-y-2 pl-5">
                    <div class="font-bold">Updates :-</div>
                    <ul class="list-disc pl-10">
                        <li>Angular - Upgraded all outdated package to latest versions.</li>
                        <li>ReactJS - Upgraded all outdated package to latest versions.</li>
                        <li>VueJS - Upgraded all outdated package to latest versions.</li>
                        <li>NextJS - Upgraded all outdated package to latest versions.</li>
                        <li>NuxtJS - Upgraded all outdated package to latest versions.</li>
                        <li>PHP - Upgraded all outdated package to latest versions.</li>
                        <li>Laravel - Upgraded all outdated package to latest versions.</li>
                        <li>ReactJS + Laravel - Upgraded all outdated package to latest versions.</li>
                        <li>VueJS + Laravel - Upgraded all outdated package to latest versions.</li>
                    </ul>
                    <div class="font-bold">Fixed Bugs :-</div>
                    <ul class="list-disc pl-10">
                        <li>Fixed other issues</li>
                    </ul>
                </div>
            </div>

            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.1.8 - 19 August, 2024</p>
                <div class="space-y-2 pl-5">
                    <div class="font-bold">Updates :-</div>
                    <ul class="list-disc pl-10">
                        <li>Angular - Upgraded version from <strong>v15.2.4</strong> to <strong>v18.2.0</strong></li>
                        <li>Angular - Upgraded all outdated packages.</li>
                    </ul>
                    <div class="font-bold">Fixed Bugs :-</div>
                    <ul class="list-disc pl-10">
                        <li>Fixed other issues</li>
                    </ul>
                </div>
            </div>

            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.1.7 - 02 March, 2024</p>
                <div class="space-y-2 pl-5">
                    <div class="font-bold">Updates :-</div>
                    <ul class="list-disc pl-10">
                        <li>HTML - Tailwind CSS version updated to v3.4</li>
                        <li>Angular - Tailwind CSS version updated to v3.4</li>
                        <li>ReactJS - Tailwind CSS version updated to v3.4</li>
                        <li>VueJS - Tailwind CSS version updated to v3.4</li>
                        <li>NextJS - Tailwind CSS version updated to v3.4</li>
                        <li>NuxtJS - Tailwind CSS version updated to v3.4</li>
                        <li>PHP - Tailwind CSS version updated to v3.4</li>
                        <li>Laravel - Tailwind CSS version updated to v3.4</li>
                        <li>ReactJS + Laravel - Tailwind CSS version updated to v3.4</li>
                        <li>VueJS + Laravel - Tailwind CSS version updated to v3.4</li>
                        <li>CakePHP - Tailwind CSS version updated to v3.4</li>
                        <li>CodeIgniter - Tailwind CSS version updated to v3.4</li>
                        <li>Symfony - Tailwind CSS version updated to v3.4</li>
                        <li>Django - Tailwind CSS version updated to v3.4</li>
                        <li>Ruby - Tailwind CSS version updated to v3.4</li>
                        <li>Adonis - Tailwind CSS version updated to v3.4</li>
                    </ul>
                    <div class="font-bold">Fixed Bugs :-</div>
                    <ul class="list-disc pl-10">
                        <li>NextJS - Installation issue using Yarn commands</li>
                        <li>NuxtJS - Installation issue using Yarn commands</li>
                    </ul>
                </div>
            </div>
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.1.6 - 12 January, 2024</p>
                <div class="space-y-2 pl-5">
                    <div class="font-bold">Updates :-</div>
                    <ul class="list-disc pl-10">
                        <li>NextJS - Added NextJS App Router Version Starter Kit</li>
                    </ul>
                    <div class="font-bold">Fixed Bugs :-</div>
                    <ul class="list-disc pl-10">
                        <li>Fixed other issues</li>
                    </ul>
                </div>
            </div>
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.1.5 - 06 January, 2024</p>
                <div class="space-y-2 pl-5">
                    <div class="font-bold">Updates :-</div>
                    <ul class="list-disc pl-10">
                        <li>NextJS - Added NextJS App Router Version</li>
                    </ul>
                    <div class="font-bold">Fixed Bugs :-</div>
                    <ul class="list-disc pl-10">
                        <li>Fixed other issues</li>
                    </ul>
                </div>
            </div>
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.1.4 - 16 September, 2023</p>
                <div class="space-y-2 pl-5">
                    <div class="font-bold">Updates :-</div>
                    <ul class="list-disc pl-10">
                        <li>Angular - Converted all svg to components</li>
                        <li>ReactJS - Converted all svg to components</li>
                        <li>VueJS - Converted all svg to components</li>
                        <li>NextJS - Converted all svg to components</li>
                        <li>NuxtJS - Converted all svg to components</li>
                    </ul>
                    <div class="font-bold">Fixed Bugs :-</div>
                    <ul class="list-disc pl-10">
                        <li>Fixed other issues</li>
                    </ul>
                </div>
            </div>
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.1.3 - 29 July, 2023</p>
                <div class="space-y-2 pl-5">
                    <div class="font-bold">Added :-</div>
                    <ul class="list-disc pl-10">
                        <li>Contact Us Cover Page</li>
                        <li>Coming Soon Boxed Page</li>
                    </ul>
                    <div class="font-bold">Updates :-</div>
                    <ul class="list-disc pl-10">
                        <li>Knowledge Base Page UI</li>
                        <li>FAQ Page UI</li>
                        <li>Error 404 Page UI</li>
                        <li>Error 500 Page UI</li>
                        <li>Error 503 Page UI</li>
                        <li>Maintenance Page UI</li>
                        <li>Contact Us Boxed Page UI</li>
                        <li>Coming Soon Cover Page UI</li>
                        <li>Login Boxed and Cover Page UI</li>
                        <li>Register Boxed and Cover Page UI</li>
                        <li>Unlock Screen Boxed and Cover Page UI</li>
                        <li>Reset Password Boxed and Cover Page UI</li>
                    </ul>
                    <div class="font-bold">Fixed Bugs :-</div>
                    <ul class="list-disc pl-10">
                        <li>Fixed other issues</li>
                    </ul>
                </div>
            </div>
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.1.2 - 15 July, 2023</p>
                <div class="space-y-2 pl-5">
                    <div class="font-bold">Added :-</div>
                    <ul class="list-disc pl-10">
                        <li>HTML - Starter Kit</li>
                        <li>Angular - Starter Kit</li>
                        <li>ReactJS - Starter Kit</li>
                        <li>VueJS - Starter Kit</li>
                        <li>NextJS - Starter Kit</li>
                        <li>NuxtJS - Starter Kit</li>
                        <li>PHP - Starter Kit</li>
                        <li>Laravel - Starter Kit</li>
                        <li>ReactJS + Laravel - Starter Kit</li>
                        <li>VueJS + Laravel - Starter Kit</li>
                        <li>CakePHP - Starter Kit</li>
                        <li>CodeIgniter - Starter Kit</li>
                        <li>Symfony - Starter Kit</li>
                        <li>Django - Starter Kit</li>
                        <li>Ruby - Starter Kit</li>
                        <li>Adonis - Starter Kit</li>
                    </ul>
                </div>
            </div>
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.1.1 - 05 July, 2023</p>
                <div class="space-y-2 pl-5">
                    <div class="font-bold">Updates :-</div>
                    <ul class="list-disc pl-10">
                        <li>Tailwind CSS version 3.3.2 update</li>
                        <li>Added arabic language</li>
                    </ul>
                    <div class="font-bold">Fixed Bugs :-</div>
                    <ul class="list-disc pl-10">
                        <li>Nuxt yarn installation issue</li>
                        <li>Fixed other issues</li>
                    </ul>
                </div>
            </div>
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.1.0 - 19 June, 2023</p>
                <div class="space-y-2">
                    <ul class="list-disc pl-10">
                        <li>Angular Version Release</li>
                    </ul>
                </div>
            </div>
            <div class="space-y-3 text-black-light">
                <p class="text-black">Version 1.0.0 - 11 March, 2023</p>
                <div class="space-y-2">
                    <ul class="list-disc pl-10">
                        <li>Initial Release</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
    definePageMeta({
        layout: 'app-layout',
    });
</script>
