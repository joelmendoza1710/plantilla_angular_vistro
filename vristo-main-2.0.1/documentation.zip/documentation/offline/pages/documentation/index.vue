<template>
    <div class="space-y-5">
        <h2 class="text-2xl font-bold text-primary">Getting Started</h2>
        <div class="panel">
            <h3 class="mb-5 text-xl font-bold text-success">Introduction to Vristo</h3>
            <div class="space-y-5 text-black-light">
                <p>
                    The VRISTO Admin template is a responsive web application built with
                    <a href="https://tailwindcss.com/docs/installation" target="_blank" class="font-semibold text-success hover:text-black">TailwindCSS</a>. It
                    includes highly customizable UI kit, Components, Widgets, Modules, Charts and Applications for you to design interfaces and powerful web
                    applications.
                </p>
                <p>
                    A glimpse of our product features are mentioned below.
                    <b
                        ><NuxtLink
                            :to="`/${route?.query?.type ? '?type=' + route?.query?.type : ''}`"
                            class="font-semibold text-success hover:text-black"
                            target="_blank"
                            >Click here</NuxtLink
                        ></b
                    >, to check our preview.
                </p>
            </div>
        </div>

        <div class="panel">
            <h3 class="mb-5 text-xl font-bold text-success">Features</h3>

            <ul class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/responsive.png" alt="" />
                    </span>
                    Fully Responsive
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/dashboard.png" alt="" />
                    </span>
                    Functional Dashboard
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/tailwindcss-icon.svg" alt="" />
                    </span>
                    Coded with Tailwind CSS
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/components.png" alt="" />
                    </span>
                    Huge Number of Components
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/clean-code.png" alt="" />
                    </span>
                    Clean Code
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/drag.png" alt="" />
                    </span>
                    Drag n Drop Section
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/apps.png" alt="" />
                    </span>
                    Working Apps Section
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/update.png" alt="" />
                    </span>
                    Free Lifetime Updates
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/datatable.png" alt="" />
                    </span>
                    Custom DataTables
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/high-performance.png" alt="" />
                    </span>
                    Fast Performance
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/gulp.png" alt="" />
                    </span>
                    Built-in Tools
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/easy-to-customize.png" alt="" />
                    </span>
                    Easy to Customize
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/support.png" alt="" />
                    </span>
                    Fast & Dedicated Support
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/landing-page.png" alt="" />
                    </span>
                    Useful Pages
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/documentation.png" alt="" />
                    </span>
                    Detailed Documentation
                </li>
            </ul>
        </div>

        <div class="panel">
            <h3 class="mb-5 text-xl font-bold text-success">Browser Compability</h3>

            <ul class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/edge.png" alt="" />
                    </span>
                    Edge (Latest)
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/opera.png" alt="" />
                    </span>
                    Opera (Latest)
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/safari.png" alt="" />
                    </span>
                    Safari (Latest)
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/mozilla.png" alt="" />
                    </span>
                    Firefox (Latest)
                </li>
                <li class="inline-flex items-center gap-3">
                    <span class="flex h-[35px] w-[35px] flex-none items-center justify-center">
                        <img src="/assets/images/chrome.png" alt="" />
                    </span>
                    Chrome (Latest)
                </li>
            </ul>
        </div>
    </div>
</template>
<script lang="ts" setup>
    definePageMeta({
        layout: 'app-layout',
    });
    const route = useRoute();
</script>
