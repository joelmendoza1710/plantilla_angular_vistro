<template>
    <div class="space-y-5">
        <h2 class="text-2xl font-bold text-primary">Support</h2>

        <div class="panel">
            <h4 class="text-center text-xl font-semibold text-black-light">
                For support and queries. Please contact us at :
                <a href="https://support.sbthemes.com/portal/en/newticket" class="text-success hover:text-black"
                    >https://support.sbthemes.com/portal/en/newticket</a
                >
                or go to themeforest comment section.
            </h4>
        </div>
    </div>
</template>
<script lang="ts" setup>
    definePageMeta({
        layout: 'app-layout',
    });
</script>
