import helperFactory from '~/factory/helper';

export default defineNuxtPlugin((nuxtApp) => {
    return {
        provide: {
            helper: helperFactory,
        },
    };
});
