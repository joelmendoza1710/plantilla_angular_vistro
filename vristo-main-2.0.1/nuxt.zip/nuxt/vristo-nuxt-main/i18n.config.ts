export default defineI18nConfig(() => ({
    fallbackLocale: 'en',
}));
