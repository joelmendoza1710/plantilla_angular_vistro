<template>
    <div>
        <ul class="flex space-x-2 rtl:space-x-reverse">
            <li>
                <a href="javascript:;" class="text-primary hover:underline">Elements</a>
            </li>
            <li class="before:content-['/'] ltr:before:mr-2 rtl:before:ml-2">
                <span>Typography</span>
            </li>
        </ul>
        <div class="grid grid-cols-1 gap-6 pt-5 lg:grid-cols-2">
            <div class="panel">
                <h5 class="mb-5 text-lg font-semibold dark:text-white-light">Heading</h5>
                <div class="mb-5 flex items-center justify-center">
                    <div class="w-full max-w-xs overflow-hidden rounded-md border border-white-dark/20 dark:border-[#191e3a]">
                        <div class="bg-white p-4 dark:bg-[#191e3a]">
                            <p class="text-4xl leading-[60px] text-[#515365] dark:text-white-light">The quick brown fox</p>
                        </div>
                        <div class="border-border-white-dark/20 border-t bg-dark-light p-4 dark:border-[#0e1726] dark:bg-[#191e3a]">
                            <h5 class="text-base dark:text-white-light">Nunito</h5>
                            <a href="javascript:;" class="text-[13px] text-primary">Google Fonts</a>
                            <div class="mt-7 flex justify-center">
                                <a href="javascript:;" class="btn btn-primary">View Family</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel">
                <h5 class="mb-5 text-lg font-semibold dark:text-white-light">Heading</h5>
                <div class="mb-5 flex items-center justify-center">
                    <div class="prose w-full max-w-xs rounded-md border border-white-dark/20 p-5">
                        <h1 class="m-0 dark:text-white-dark">H1. Heading</h1>
                        <h2 class="m-0 dark:text-white-dark">H2. Heading</h2>
                        <h3 class="m-0 dark:text-white-dark">H3. Heading</h3>
                        <h4 class="m-0 dark:text-white-dark">H4. Heading</h4>
                        <h5 class="m-0 dark:text-white-dark">H5. Heading</h5>
                        <h6 class="m-0 dark:text-white-dark">H6. Heading</h6>
                    </div>
                </div>
            </div>

            <div class="panel">
                <h5 class="mb-5 text-lg font-semibold dark:text-white-light">Heading Colored</h5>
                <div class="mb-5 flex items-center justify-center">
                    <div class="prose w-full max-w-xs rounded-md border border-white-dark/20 p-5">
                        <h1 class="m-0 text-primary">H1. Heading</h1>
                        <h2 class="m-0 text-info">H2. Heading</h2>
                        <h3 class="m-0 text-success">H3. Heading</h3>
                        <h4 class="m-0 text-warning">H4. Heading</h4>
                        <h5 class="m-0 text-danger">H5. Heading</h5>
                        <h6 class="m-0 text-secondary">H6. Heading</h6>
                    </div>
                </div>
            </div>

            <div class="panel">
                <h5 class="mb-5 text-lg font-semibold dark:text-white-light">Icon List</h5>
                <div class="mb-5 flex items-center justify-center">
                    <div class="w-full max-w-xs rounded-md border border-white-dark/20 p-5">
                        <ul class="space-y-3 font-semibold">
                            <li>
                                <icon-arrow-left class="inline text-primary rtl:rotate-180 ltr:mr-2 rtl:ml-2" />
                                <span class="list-text">Aliquam et eros vehicula.</span>
                            </li>
                            <li>
                                <icon-arrow-left class="inline text-primary rtl:rotate-180 ltr:mr-2 rtl:ml-2" />
                                <span class="list-text">Vivamus lacus suscipit.</span>
                            </li>
                            <li>
                                <icon-arrow-left class="inline text-primary rtl:rotate-180 ltr:mr-2 rtl:ml-2" />
                                <span class="list-text">Morbi luctus tincidunt.</span>
                            </li>
                            <li>
                                <icon-arrow-left class="inline text-primary rtl:rotate-180 ltr:mr-2 rtl:ml-2" />
                                <span class="list-text">Nulla metus dolor.</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="panel">
                <h5 class="mb-5 text-lg font-semibold dark:text-white-light">Unordered list</h5>
                <div class="mb-5 flex items-center justify-center">
                    <div class="w-full max-w-xs rounded-md border border-white-dark/20 p-5 text-white-dark">
                        <ul class="list-inside list-disc space-y-3 font-semibold">
                            <li class="mb-1">Consectetur adipiscing elit</li>
                            <li class="mb-1">Integer molestie lorem at massa</li>
                            <li class="mb-1">Facilisis in pretium nisl aliquet</li>
                            <li class="inline">
                                <ul class="list-inside space-y-3 ltr:pl-5 rtl:pr-5">
                                    <li class="mb-1 mt-1">Phasellus iaculis neque</li>
                                    <li class="mb-1">Purus sodales ultricies</li>
                                    <li class="mb-1">Ac tristique libero volutpat at</li>
                                </ul>
                            </li>
                            <li class="mb-1 mt-1">Faucibus porta lacus fringilla vel</li>
                            <li class="mb-1">Aenean sit amet erat nunc</li>
                            <li class="mb-1">Eget porttitor lorem</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="panel">
                <h5 class="mb-5 text-lg font-semibold dark:text-white-light">Ordered list</h5>
                <div class="mb-5 flex items-center justify-center">
                    <div class="w-full max-w-xs rounded-md border border-white-dark/20 p-5 text-white-dark">
                        <ol class="list-inside list-decimal space-y-3 font-semibold">
                            <li class="mb-1">Consectetur adipiscing elit</li>
                            <li class="mb-1">Integer molestie lorem at massa</li>
                            <li class="mb-1">Facilisis in pretium nisl aliquet</li>
                            <li class="inline">
                                <ol class="list-inside list-decimal space-y-3 ltr:pl-5 rtl:pr-5">
                                    <li class="mb-1 mt-1">Phasellus iaculis neque</li>
                                    <li class="mb-1">Purus sodales ultricies</li>
                                    <li class="mb-1">Ac tristique libero volutpat at</li>
                                </ol>
                            </li>
                            <li class="mb-1 mt-1">Faucibus porta lacus fringilla vel</li>
                            <li class="mb-1">Aenean sit amet erat nunc</li>
                            <li class="mb-1">Eget porttitor lorem</li>
                        </ol>
                    </div>
                </div>
            </div>

            <div class="panel">
                <h5 class="mb-5 text-lg font-semibold dark:text-white-light">Blockquote</h5>
                <div class="mb-5 flex items-center justify-center">
                    <blockquote
                        class="rounded-tr-md rounded-br-md border border-l-2 border-white-light !border-l-primary bg-white p-5 text-black shadow-md ltr:pl-3.5 rtl:pr-3.5 dark:border-[#060818] dark:bg-[#060818]"
                    >
                        <div class="flex items-start">
                            <p class="m-0 text-sm not-italic text-[#515365] dark:text-white-light">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.
                            </p>
                        </div>
                        <small
                            class="block w-full text-xs not-italic text-[#777] before:relative before:-top-1 before:inline-block before:h-[1px] before:w-3 before:bg-[#777] before:opacity-50 ltr:before:mr-1 rtl:before:ml-1"
                            >Someone famous <cite class="italic">Source Title</cite></small
                        >
                    </blockquote>
                </div>
            </div>

            <div class="panel">
                <h5 class="mb-5 text-lg font-semibold dark:text-white-light">Blockquote with profile</h5>
                <div class="mb-5 flex items-center justify-center">
                    <blockquote
                        class="rounded-tr-md rounded-br-md border border-l-2 border-white-light !border-l-primary bg-white p-5 text-black shadow-md ltr:pl-3.5 rtl:pr-3.5 dark:border-[#060818] dark:bg-[#060818]"
                    >
                        <div class="flex items-start">
                            <div class="h-14 w-14 flex-none ltr:mr-5 rtl:ml-5">
                                <img src="/assets/images/profile-34.jpeg" alt="" class="m-auto h-14 w-14 rounded-full object-cover" />
                            </div>
                            <p class="m-0 text-sm not-italic text-[#515365] dark:text-white-light">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.
                            </p>
                        </div>
                        <small
                            class="block w-full text-xs not-italic text-[#777] before:relative before:-top-1 before:inline-block before:h-[1px] before:w-3 before:bg-[#777] before:opacity-50 ltr:text-right ltr:before:mr-1 rtl:text-left rtl:before:ml-1"
                            >Someone famous <cite class="italic">Source Title</cite></small
                        >
                    </blockquote>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
    useHead({ title: 'Typography' });
</script>
