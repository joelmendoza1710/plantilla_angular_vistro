module TablesHelper
end
