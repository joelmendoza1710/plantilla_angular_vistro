<template>
    <div>
        <h1>starter page</h1>
    </div>
</template>
